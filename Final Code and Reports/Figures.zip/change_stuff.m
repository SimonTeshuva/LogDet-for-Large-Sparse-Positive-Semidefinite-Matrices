a=open('1bii2.fig');
x=xlabel('Matrix Size');
y=ylabel('Relative Accuracy');
x.FontSize=14;
y.FontSize=14;
% l=legend('');
% l.FontSize=14;
t=title('Relative Accuracy on Kneser Based Matricies');
t.FontSize=14;
lines = findobj(gcf,'Type','Line');
for i = 1:numel(lines)
  lines(i).LineWidth = 2*i;
end
legend('Chebyshev','Rational');